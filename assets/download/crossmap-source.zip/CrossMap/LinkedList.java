
public class LinkedList {

    ListNode head;
    ListNode tail;
    private Comparator comparator;

    public LinkedList(Comparator comparator) {
        head = null;
        tail = null;
        this.comparator = comparator;
    }

    public boolean isEmpty() {
        return (head == null);
    }

    public void addToHead(Object item) {
        if (isEmpty()) {
            head = tail = new ListNode(item);
        } else {
            head = new ListNode(item, head);
        }
    }

    public void addToTail(Object item) {
        if (isEmpty()) {
            head = tail = new ListNode(item);
        } else {
            tail.next = new ListNode(item);
            tail = tail.next;
        }
    }

    public void insertIdentifierInOrder(String identifier, int lineNumber) {
        // Insert the identifier in ASCII order
        if (isEmpty()) {
            addToHead(new IdentifierNode(identifier, lineNumber));
        } else {
            ListNode current = head;
            ListNode prev = null;

            while (current != null && comparator.isLessThan(((IdentifierNode) current.data).identifier, identifier)) {
                prev = current;
                current = current.next;
            }

            // Check if the identifier already exists in the list
            if (current != null && comparator.isEqualTo(((IdentifierNode) current.data).identifier, identifier)) {
                // Identifier already exists, add the line number to the existing identifier node
                ((IdentifierNode) current.data).addLineNumber(lineNumber);
                return;
            }

            if (prev == null) {
                addToHead(new IdentifierNode(identifier, lineNumber));
            } else {
                prev.next = new ListNode(new IdentifierNode(identifier, lineNumber), current);
                if (current == null) {
                    // Update tail if the new identifier is added at the end
                    tail = prev.next;
                }
            }
        }
    }

    public void displayIdentifiers() {
        ListNode current = head;
        while (current != null) {
            System.out.println(current.data);
            current = current.next;
        }
    }

    public String toString() {
        String s = "[ ";
        ListNode current = head;
        while (current != null) {
            s += current.data + " ";
            current = current.next;
        }
        return s + "]";
    }

    private int countLineNumbers(LinkedList lineNumbersList) {
        int count = 0;
        ListNode current = lineNumbersList.head;
        while (current != null) {
            count++;
            current = current.next;
        }
        return count;
    }

    public int getTotalCount() {
        int totalCount = 0;
        ListNode current = head;
        while (current != null) {
            IdentifierNode identifierNode = (IdentifierNode) current.data;
            int count = countLineNumbers(identifierNode.lineNumbers);
            totalCount += count;
            current = current.next;
        }
        return totalCount;
    }

}
