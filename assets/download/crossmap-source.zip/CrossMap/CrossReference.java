/**
* Cross Reference Map
* 
* I understand the meaning of academic dishonesty, in particular plagiarism, copyright infringement
* and collusion. I am aware of the consequences if found to be involved in these misconducts. I hereby
* declare that the work submitted for the "ITP4510 Data Structures & Algorithms" is authentic record
* of my own work. 
*
* @Name : SUM Ka On
* @StdID: 230097594
* @Class: IT114105/1A
* @2024-03-14
*/
import java.util.*;
import java.io.*;

public class CrossReference {

    private static final String DELIMITER = "\"(?:\\\\\"|[^\"])*?\"|[\\s.,;:+*/|!=><@?#%&(){}\\-\\^\\[\\]\\&&]+";

    public static String[] tokenizer(String javaStmt) {
        String[] tokens = javaStmt.split(DELIMITER);
        return tokens;
    }

    public static final String[] JAVA_KEYWORDS = {
        "abstract", "assert", "boolean", "break", "byte", "case", "catch", "char", "class", "const",
        "continue", "default", "do", "double", "else", "enum", "extends", "final", "finally", "float",
        "for", "goto", "if", "implements", "import", "instanceof", "int", "interface", "long", "native",
        "new", "package", "private", "protected", "public", "return", "short", "static", "strictfp",
        "super", "switch", "synchronized", "this", "throw", "throws", "transient", "true", "try", "void",
        "volatile", "while", "false", "null"
    };

    public static void main(String[] args) throws FileNotFoundException {
        Comparator c = new StringComparator();
        LinkedList identifierList = new LinkedList(c);

        try {
            String filename = args[2];
            String line;
            int lineNumber = 1;
            System.out.println("SOURCE FILE: " + filename);
            Scanner fin = new Scanner(new File(filename));
            while (fin.hasNextLine()) {
                line = fin.nextLine();
                System.out.printf("%04d | %s%n", lineNumber, line);
                String[] tokens = tokenizer(line);
                for (String token : tokens) {
                    // Modified regex to correctly identify Java identifiers
                    if (token.matches("[A-Za-z$_][A-Za-z0-9$_]*")) {
                        boolean isJavaKeyword = false;
                        for (int i = 0; i < JAVA_KEYWORDS.length; i++) {// Check if the token is a Java keyword
                            if (token.equals(JAVA_KEYWORDS[i])) {
                                isJavaKeyword = true;
                                break;
                            }
                        }
                        if (!isJavaKeyword) {
                            identifierList.insertIdentifierInOrder(token, lineNumber);
                        }
                    }
                }
                lineNumber++;
            }

            System.out.println("\nCross Map Reference :-");
            identifierList.displayIdentifiers();
            System.out.println("\nTotal identifier(s) extracted: " + identifierList.getTotalCount());
        } catch (FileNotFoundException e) {
            System.out.println("Failed to open file " + args[2]);
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Usage: java CrossReference <filename>");
        }
    }
}
