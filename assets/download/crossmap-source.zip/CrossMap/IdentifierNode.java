
public class IdentifierNode {

    public String identifier;
    public LinkedList lineNumbers;

    public IdentifierNode(String identifier, int lineNumber) {
        this.identifier = identifier;
        this.lineNumbers = new LinkedList(new StringComparator());
        lineNumbers.addToTail(lineNumber);
    }

    public void addLineNumber(int lineNumber) {
        lineNumbers.addToTail(lineNumber);
    }

    @Override
    public String toString() {
        return identifier + ": " + lineNumbers;
    }

}
